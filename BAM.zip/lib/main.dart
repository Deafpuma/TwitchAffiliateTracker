import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'config/app_initializer.dart';
import 'screens/home_screen.dart';
import 'services/auth_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());

  // ✅ Load .env file before anything else
  try {
    await dotenv.load(fileName: "assets/.env");
    print("✅ .env loaded successfully.");
  } catch (e) {
    print("❌ ERROR: Could not load .env file: $e");
  }

  // ✅ Initialize Firebase
  await AppInitializer.initialize();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Twitch Affiliate Tracker',
      theme: ThemeData(primarySwatch: Colors.purple),
      home: const AuthWrapper(),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snapshot.hasData) {
          return HomeScreen(); // ✅ Redirects to home after login
        } else {
          return Scaffold(
            body: Center(
              child: ElevatedButton(
                onPressed: () async {
                  try {
                    await AuthService().signInWithTwitch();
                  } catch (e) {
                    print("❌ Twitch login failed: $e");
                  }
                },
                child: const Text("Login with Twitch"),
              ),
            ),
          );
        }
      },
    );
  }



}
