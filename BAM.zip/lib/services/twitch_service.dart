import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class TwitchService {
  final String clientId = dotenv.env['TWITCH_CLIENT_ID'] ?? "";
  final String clientSecret = dotenv.env['TWITCH_CLIENT_SECRET'] ?? "";
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Fetch the stored Twitch OAuth token from Firestore
  Future<Map<String, String?>> getStoredTwitchTokens() async {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user == null) return {"accessToken": null, "refreshToken": null};

    final userDoc = await _firestore.collection("users").doc(user.uid).get();
    return {
      "accessToken": userDoc.data()?["twitch_oauth_token"],
      "refreshToken": userDoc.data()?["twitch_refresh_token"]
    };
  }

  /// Fetch Twitch User Data
  Future<Map<String, dynamic>> getUserData({String? passedToken}) async {
    try {
      final tokens = await getStoredTwitchTokens();
      String? accessToken = passedToken ?? tokens["accessToken"];
      final String? refreshToken = tokens["refreshToken"];

      if (accessToken == null) {
        throw Exception("❌ No valid Twitch access token stored!");
      }

      final response = await http.get(
        Uri.parse('https://api.twitch.tv/helix/users'),
        headers: {
          'Authorization': 'Bearer $accessToken',
          'Client-Id': clientId,
        },
      );

      if (response.statusCode == 401 && refreshToken != null) {
        // 🔄 Refresh token if expired
        print("🔄 Twitch token expired, refreshing...");
        accessToken = await refreshAccessToken(refreshToken);
        if (accessToken == null) throw Exception("❌ Failed to refresh Twitch token!");

        // Retry API call with the new token
        final retryResponse = await http.get(
          Uri.parse('https://api.twitch.tv/helix/users'),
          headers: {
            'Authorization': 'Bearer $accessToken',
            'Client-Id': clientId,
          },
        );

        if (retryResponse.statusCode == 200) {
          final data = jsonDecode(retryResponse.body);
          return data['data'][0];
        } else {
          throw Exception("❌ Failed to fetch Twitch user data: ${retryResponse.body}");
        }
      }

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'][0];
      } else {
        throw Exception("❌ Failed to fetch Twitch user data: ${response.body}");
      }
    } catch (e) {
      print("❌ Error fetching Twitch data: $e");
      return {};
    }
  }

  /// Refresh the Twitch Access Token
  Future<String?> refreshAccessToken(String refreshToken) async {
    try {
      final response = await http.post(
        Uri.parse('https://id.twitch.tv/oauth2/token'),
        body: {
          'client_id': clientId,
          'client_secret': clientSecret,
          'refresh_token': refreshToken,
          'grant_type': 'refresh_token',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final String newAccessToken = data['access_token'];
        final String newRefreshToken = data['refresh_token'];

        // 🔥 Update Firestore with new tokens
        final User? user = FirebaseAuth.instance.currentUser;
        if (user != null) {
          await _firestore.collection("users").doc(user.uid).update({
            "twitch_oauth_token": newAccessToken,
            "twitch_refresh_token": newRefreshToken,
          });
          print("✅ Updated Firestore with new Twitch tokens.");
        }

        return newAccessToken;
      } else {
        throw Exception("❌ Failed to refresh token: ${response.body}");
      }
    } catch (e) {
      print("❌ Error refreshing Twitch token: $e");
      return null;
    }
  }
}
