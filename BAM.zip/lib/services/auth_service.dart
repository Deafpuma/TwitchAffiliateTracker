import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> signInWithTwitch() async {
    try {
      final provider = OAuthProvider("oidc.twitch");

      // ✅ Required OAuth Scopes
      provider.addScope("openid");
      provider.addScope("user:read:email");

      // 🔄 Authenticate User
      final UserCredential credential = await _auth.signInWithProvider(provider);
      final User? user = credential.user;

      if (user == null) throw Exception("❌ User authentication failed!");

      print("✅ User Info: ${user.email}, ${user.displayName}, ${user.uid}");

      // **🔍 Retrieve OAuth Credentials Safely**
      if (credential.credential is OAuthCredential) {
        final OAuthCredential oauthCred = credential.credential as OAuthCredential;

        final String? accessToken = oauthCred.accessToken;
        final String? idToken = oauthCred.idToken; // Twitch may not return refreshToken

        print("🔄 Access Token: $accessToken");
        print("🔄 ID Token: $idToken");

        if (accessToken == null) {
          throw Exception("❌ Failed to retrieve Twitch access token.");
        }

        // 🔥 Store Tokens in Firestore
        await _firestore.collection("users").doc(user.uid).set({
          "email": user.email ?? "",
          "displayName": user.displayName ?? "",
          "photoURL": user.photoURL ?? "",
          "twitch_oauth_token": accessToken,
          "twitch_refresh_token": idToken, // May be null
          "created_at": FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));

        print("✅ Twitch authentication successful!");
      } else {
        throw Exception("❌ Failed to retrieve OAuth credentials.");
      }
    } catch (e) {
      print("❌ Twitch Authentication Error: $e");
    }
  }

  /// Get current user
  User? getCurrentUser() {
    return _auth.currentUser;
  }

  /// Sign out
  Future<void> signOut() async {
    await _auth.signOut();
    print("✅ Successfully signed out");
  }
}
