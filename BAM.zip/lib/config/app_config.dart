class AppConfig {
  static const String twitchClientId = "YOUR_TWITCH_CLIENT_ID";
  static const String twitchClientSecret = "YOUR_TWITCH_CLIENT_SECRET";
  static const String twitchRedirectUri = "YOUR_TWITCH_REDIRECT_URI";
}
