class AppConstants {
  static const String appName = "Twitch Affiliate Tracker";
  static const String twitchBaseUrl = "https://api.twitch.tv/helix/";
}
