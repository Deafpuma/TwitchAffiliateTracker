import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return FirebaseOptions(
        apiKey: "AIzaSyCX29RECycGU2fS3GpF5FwNwvRiPMycuNY",
        appId: "1:530286876886:android:c6a6e6e617a8b843e41177",
        messagingSenderId: "530286876886",
        projectId: "twitchstreamtracker-6e480",
        authDomain: "twitchstreamtracker-6e480.firebaseapp.com",
        storageBucket: "twitchstreamtracker-6e480.appspot.com",
        measurementId: "G-N4N5F8Y37P"
    );
  }
}